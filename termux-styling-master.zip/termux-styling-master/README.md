Termux:Styling
--------------
[![Join the chat at https://gitter.im/termux/termux](https://badges.gitter.im/termux/termux.svg)](https://gitter.im/termux/termux)

A [Termux](https://termux.com/) add-on app to customize the terminal font and color theme.

- [Termux:Styling on Google Play](https://play.google.com/store/apps/details?id=com.termux.styling)
- [Termux:Styling on F-Droid](https://f-droid.org/repository/browse/?fdid=com.termux.styling)

When developing (or packaging), note that this app needs to be signed with the same key as the main Termux app in order to have the permission to modify the required font or color files.

License
=======
Released under the [GPLv3 license](http://www.gnu.org/licenses/gpl-3.0.en.html).

How to use
==========
1. When inside Termux, long press anywhere on the terminal.
2. Select `More...` in the resulting dialog.
3. Select `Style` in the next dialog.
4. Click either `CHOOSE COLOR` or `CHOOSE FONT` depending on what you want to customize.
