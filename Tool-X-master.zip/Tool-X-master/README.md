
<h1 align="center">Tool-X v2.0</h1>
<p align="center">
       Tool-X is a kali linux hacking tool installer.
</p>

### What is Tool-X ?

Tool-X is a kali linux hacking Tool installer. Tool-X developed for termux and other android terminals. using Tool-X you can install almost 263 hacking tools in termux app and other linux based distributions. Now Tool-X is available for ubuntu, debian etc.

[![Build Status](https://img.shields.io/github/forks/Rajkumrdusad/Tool-X.svg)](https://github.com/Rajkumrdusad/Tool-X)
[![Build Status](https://img.shields.io/github/stars/Rajkumrdusad/Tool-X.svg)](https://github.com/Rajkumrdusad/Tool-X)
[![License](https://img.shields.io/github/license/Rajkumrdusad/Tool-X.svg)](https://github.com/Rajkumrdusad/Tool-X)
[![Rawsec's CyberSecurity Inventory](https://inventory.rawsec.ml/img/badges/Rawsec-inventoried-FF5050_flat.svg)](https://inventory.rawsec.ml/tools.html#Tool-X)

<p align="center">
<img src="https://github.com/Rajkumrdusad/Tool-X/blob/master/.sc/Logo.jpg"/>
</p>

<br/><br/><br/>

# How to use ?

- Type 0 : To install all tools.
- Type 1 : to sow all available tools and type the number of a tool which you want to install.
- Type 2 : to show tools category.
- Type 3 : for install operating system in termux
- Type 4 : if you want to update Tool-X.
- Type 5 : if you know About us.
- Type x : for exit.

<br/>

### Tool-X is available for

* Android
* Ubuntu

<br/>

# How to Install in Tool-X ?

Open the terminal and type following commands.

* `apt update`

* `apt install git`

* `git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sh install.aex` if not work than use `./install.aex`

<br/>

**Now Tool-X is installed successfully. To run Tool-X Type Tool-X in your terminal.**

Type Tool-X from anywhare in your terminal to open Tool-X.

<br/>

## Warning

***I am not expert so use this tool at your own risk.***

