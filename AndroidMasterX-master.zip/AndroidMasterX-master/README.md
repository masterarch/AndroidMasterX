# AndroidMasterX
chmod 700 Android*
