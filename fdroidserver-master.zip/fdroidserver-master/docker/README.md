# dscanner docker image #

Use `make help` for up-to-date instructions.

```
usage: make {help|build|clean|kill|info}

  help    this help screen
  build   create docker image
  clean   remove images and containers
  kill    stop running containers
  info    details of running container
```
