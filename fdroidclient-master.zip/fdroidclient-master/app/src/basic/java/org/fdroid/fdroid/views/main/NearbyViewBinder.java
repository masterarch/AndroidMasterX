package org.fdroid.fdroid.views.main;

import android.app.Activity;
import android.content.Intent;

class NearbyViewBinder {
    static void onActivityResult(Activity activity, Intent data) {
        throw new IllegalStateException("unimplemented");
    }
}
